import 'db_base.dart';

class ProfessionalExperiencesTable extends DBBaseTable {
  @override
  String get db_table => 'professional_experiences';  // Table name

  // You can add custom methods for the `professional_experiences` table if necessary
}
