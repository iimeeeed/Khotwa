import 'db_base.dart';

class CompaniesTable extends DBBaseTable {
  @override
  String get db_table => 'companies';  // Table name

  // You can add custom methods for the `companies` table if necessary
}
