import 'db_base.dart';

class EducationExperiencesTable extends DBBaseTable {
  @override
  String get db_table => 'education_experiences';  // Table name

  // You can add custom methods for the `education_experiences` table if necessary
}
