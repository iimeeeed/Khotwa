import 'db_base.dart';

class JobsTable extends DBBaseTable {
  @override
  String get db_table => 'jobs';  // Table name

  // You can add custom methods for the `jobs` table if necessary
}
