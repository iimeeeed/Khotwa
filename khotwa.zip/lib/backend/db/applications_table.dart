import 'db_base.dart';

class ApplicationsTable extends DBBaseTable {
  @override
  String get db_table => 'applications';  // Table name

  // You can add custom methods for the `applications` table if necessary
}
